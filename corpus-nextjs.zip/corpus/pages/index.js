import CorpusApp from '../components/App'
export default function Home() {
  return <CorpusApp />
}
